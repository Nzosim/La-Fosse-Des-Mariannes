public class ProgJeu {
    public static void main(String[] args) {
        Jeu j = new Jeu(60, "../cartes/timeline.txt");
        j.fonctionnement();
    }
}
