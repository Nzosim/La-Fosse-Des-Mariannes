package libtest;

public @interface Test {

}
